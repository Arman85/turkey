<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Заявка с сайта www.turkey.zetatour.kz</title>
</head>
<body>
	<h1>Новая заявка с сайта: <a href="http://turkey.zetatour.kz">www.turkey.zetatour.kz</a></h1>
	<p>Имя клиента: {{ $name }}</p>
	<p>Телефон: {{ $phone }}</p>
</body>
</html>