<div class="moto-widget moto-widget-block moto-bg-color_custom1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="block" data-spacing="aaaa" style="">
      
      <div class="container-fluid">
          <div class="row">
              <div class="moto-cell col-sm-12" data-container="container">
                  
              <div data-widget-id="wid_1516193448_9dip5rheg" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto "
      data-widget="spacer" data-preset="default" data-spacing="mama" data-visible-on="mobile-v">
      <div class="moto-widget-spacer-block" style="height:10px"></div>
  </div><div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="">
      
      <div class="container-fluid">
          <div class="row" data-container="container">
              
                  
                      <div class="moto-widget moto-widget-row__column moto-cell col-sm-12 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa">
      
  <div data-widget-id="wid_1516193432_ahky8s3pe" class="moto-widget moto-widget-image moto-preset-default moto-align-center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto  " data-widget="image">
                          <a class="myfooter moto-widget-image-link moto-link" href="/"   data-action="page" style="width: 280px; height: 90px;">
                  <img data-src="<?php echo e(asset('images/turkey/turk-logo-2.png')); ?>" class="moto-widget-image-picture lazyload mylogo" data-id="181" title="" alt="">
              </a>
              </div></div>

                  
              
          </div>
      </div>
  </div><div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="">
      
      <div class="container-fluid">
          <div class="row" data-container="container">
              
                  
                      <div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa">
      
  </div><div class="moto-widget moto-widget-row__column moto-cell col-sm-6 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa">
      
  <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sasa" data-animation="">
      <div class="moto-widget-text-content moto-widget-text-editable"><p style="text-align: center;" class="moto-text_normal"><span class="moto-color5_5 mymoto-color5_5">Удивительное ближе чем кажется!</span></p></div>
  </div><div data-widget-id="wid_1516193524_7hulkympp" class="moto-widget moto-widget-social-links moto-preset-2 moto-align-center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto  " data-widget="social_links" data-preset="2">
          <ul class="moto-widget-social-links-list">
                                                          <li class="moto-widget-social-links-item">
                          <a href="http://demolink.motocms.com/" class="moto-widget-social-links-link moto-widget-social-links-link_facebook" data-provider="facebook" target="_blank"></a>
                      </li>
                                                                                  <li class="moto-widget-social-links-item">
                          <a href="http://demolink.motocms.com/" class="moto-widget-social-links-link moto-widget-social-links-link_twitter" data-provider="youtube" target="_blank"></a>
                      </li>
                                                                                  <li class="moto-widget-social-links-item">
                          <a href="http://demolink.motocms.com/" class="moto-widget-social-links-link moto-widget-social-links-link_googleplus" data-provider="googleplus" target="_blank"></a>
                      </li>
                                                                                  <li class="moto-widget-social-links-item">
                          <a href="http://demolink.motocms.com/" class="moto-widget-social-links-link moto-widget-social-links-link_linkedin" data-provider="linkedin" target="_blank"></a>
                      </li>
                                                                                  <li class="moto-widget-social-links-item">
                          <a href="http://demolink.motocms.com/" class="moto-widget-social-links-link moto-widget-social-links-link_pinterest" data-provider="pinterest" target="_blank"></a>
                      </li>
                                                                                      </ul>
      </div><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="saaa" data-animation="">
      <div class="moto-widget-text-content moto-widget-text-editable"><p style="text-align: center;" class="moto-text_normal">Copyright 2018. Zeta tour. Все права защищены.<!-- <br>Designed by <a target="_blank" rel="nofollow" data-action="url" class="moto-link" href="https://motocms.com">MotoCMS.com</a> --></p></div>
  </div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa">
      
  </div>

                  
              
          </div>
      </div>
  </div><div data-widget-id="wid_1516193619_1w56kvyku" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto "
      data-widget="spacer" data-preset="default" data-spacing="mama" data-visible-on="mobile-v">
      <div class="moto-widget-spacer-block" style="height:0px"></div>
  </div></div>
          </div>
      </div>
  </div> 